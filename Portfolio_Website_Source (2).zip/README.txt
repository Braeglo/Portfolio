BRAEDEN LOCK | PORTFOLIO

Open index.html to preview your full single-page portfolio.
The site uses HTML and CSS. Lucide icons are bundled locally in assets.

PUBLISH ON GITHUB PAGES
1. Sign in to GitHub and create a public repository named portfolio.
2. Choose Add file > Upload files.
3. Upload index.html, styles.css, and the assets folder at the repository root.
   Do not upload the ZIP itself. Keep the assets folder and its contents together.
4. Commit changes.
5. Open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose main and / (root), then Save.
8. Wait for the published link to appear. Open it to confirm the page works.
9. Paste that exact live link into the Website URL field on the submission PDF.
10. Review the first-person reflection drafts so they match your experience,
    save the completed PDF, and upload the PDF to your assignment.

The project descriptions are portfolio summaries, not links to deployed demos.
Update them with your project URLs when available.

Icons: Lucide (ISC license); license included in assets/LUCIDE-LICENSE.
